# LeadHunter AI — Developer Complete Build

Core architecture:
- `lead_engine.py`: structured conversation memory, multi-fact extraction, property-specific qualification flows, scoring.
- `app.py`: Streamlit buyer chat + broker dashboard.
- `test_lead_engine.py`: regression suite.

Important behaviour:
- Hi -> natural greeting.
- One message can contain many facts; all are retained.
- “Budget no issue” -> stored as flexible budget; budget is not asked again.
- “Any area” -> stored as flexible area; area is not asked again.
- “2 or 3 BHK” -> accepted.
- “Empty plot” -> Plot flow; plot buyers are asked plot size, never possession.
- “I already told you” -> uses memory rather than restarting.
- Once the relevant flow is complete, it stops qualifying and offers the next action.

Deployment:
Replace `app.py`, `lead_engine.py`, and `requirements.txt` in GitHub. Do not upload `.pyc` files.
