
from dataclasses import dataclass, field, asdict
from datetime import datetime
import re
from typing import Optional, Dict, Tuple

FIELDS = {
    "property_type":"property type","area":"preferred area","budget":"budget",
    "possession":"possession preference","plot_size":"plot size",
    "purpose":"purpose","timeline":"purchase timeline","name":"name","phone":"phone/WhatsApp"
}
AREAS = ["nanded station","nanded railway station","cidco nanded","cidco","vazirabad",
         "taroda","shivaji nagar","airport road","kabra nagar","anand nagar",
         "purna road","miyapur","hafeezpet","kukatpally"]

@dataclass
class LeadMemory:
    property_type: Optional[str]=None
    area: Optional[str]=None
    budget: Optional[str]=None
    possession: Optional[str]=None
    plot_size: Optional[str]=None
    purpose: Optional[str]=None
    timeline: Optional[str]=None
    name: Optional[str]=None
    phone: Optional[str]=None
    confidence: Dict[str,float]=field(default_factory=dict)
    updated_at: str=field(default_factory=lambda: datetime.now().isoformat(timespec="seconds"))

@dataclass
class Result:
    reply:str
    memory:LeadMemory
    changed:Dict[str,str]
    missing:Optional[str]
    score:int
    status:str
    complete:bool

def n(s): return re.sub(r"\s+"," ",(s or "").strip().lower())
def clean(s): return re.sub(r"\s+"," ",s.strip(" .,;:-")).strip()

def greeting(s):
    return n(s) in {"hi","hello","hey","hii","hiii","helo","namaste","good morning","good afternoon","good evening"}

def flexible(s, field):
    x=n(s)
    p={
      "budget":["budget no issue","budget is no issue","any budget","no budget limit","budget doesn't matter","budget doesnt matter","money no issue","price no issue","budget flexible","budget is flexible","any price","no fixed budget"],
      "area":["any area","anywhere","any location","any locality","area flexible","location flexible","no area preference","no location preference","location no issue","area no issue"],
      "possession":["no preference","either is fine","either one","anything is fine","doesn't matter","doesnt matter","any is fine"],
      "timeline":["no hurry","flexible timeline","timeline flexible","no fixed timeline","anytime","not decided"]
    }
    return any(v in x for v in p.get(field,[]))

def extract_facts(text):
    raw=text or ""; x=n(raw); d={}
    if re.search(r"\b(?:empty|open|residential)\s+plott?s?\b|\bplott?s?\b",x): d["property_type"]="Plot"
    elif "commercial" in x or "shop" in x or "office space" in x: d["property_type"]="Commercial"
    elif re.search(r"\b([1-5])\s*(?:or|/|and)\s*([1-5])\s*(?:bhk|bedroom)\b",x):
        m=re.search(r"\b([1-5])\s*(?:or|/|and)\s*([1-5])\s*(?:bhk|bedroom)\b",x)
        d["property_type"]=f"{m.group(1)} or {m.group(2)} BHK"
    else:
        m=re.findall(r"\b([1-5])\s*(?:bhk|bedroom)\b",x)
        if m: d["property_type"]=f"{m[0]} BHK"

    if flexible(x,"budget"): d["budget"]="Flexible / no fixed limit"
    else:
        m=re.search(r"(?:rs\.?|inr)?\s*([0-9]+(?:\.[0-9]+)?)\s*(lakh|lac|lakhs|crore|cr)\b",x)
        if m: d["budget"]=f"₹{m.group(1)} {m.group(2).lower()}"

    if flexible(x,"area"): d["area"]="Any area / flexible"
    else:
        found=sorted([a for a in AREAS if a in x],key=len,reverse=True)
        if found:
            keep=[]
            for a in found:
                if not any(a in z or z in a for z in keep): keep.append(a)
            d["area"]=", ".join(z.title() for z in reversed(keep))
        else:
            m=re.search(r"\bnear\s+([a-z][a-z0-9 .-]{2,35}?)(?=\s+(?:budget|around|within|ready|under|move|for|and|,|\.|$))",raw,re.I)
            if m: d["area"]=clean(m.group(1)).title()

    if any(v in x for v in ["ready to move","ready-to-move","ready possession","ready for possession","immediate possession"]): d["possession"]="Ready to move"
    elif "under construction" in x: d["possession"]="Under construction"
    elif flexible(x,"possession"): d["possession"]="No preference"

    if any(v in x for v in ["within 1 month","in 1 month","this month","immediately","urgent","within a month"]): d["timeline"]="Within 1 month"
    else:
        m=re.search(r"\b(?:in|within)\s+([2-9])\s*months?\b",x)
        if m: d["timeline"]=f"Within {m.group(1)} months"
        else:
            m=re.search(r"\b([1-9])\s*(?:-|to)\s*([1-9])\s*months?\b",x)
            if m: d["timeline"]=f"{m.group(1)}–{m.group(2)} months"
            elif flexible(x,"timeline"): d["timeline"]="Flexible"

    m=re.search(r"\b([0-9]+(?:\.[0-9]+)?)\s*(sq\.?\s*ft|sqft|square feet|sq\.?\s*yd|square yards|guntha|acre|acres)\b",x)
    if m: d["plot_size"]=f"{m.group(1)} {m.group(2)}"
    if re.search(r"\binvest(?:ment|ing)\b",x): d["purpose"]="Investment"
    elif any(v in x for v in ["self use","self-use","own use","for living"]): d["purpose"]="Self-use"

    m=re.search(r"\b(?:my name is|i am|i'm|im|it's)\s+([a-zA-Z][a-zA-Z ]{1,35}?)(?=\s*[,.;]|\s+(?:need|want|looking|for|in|near|with)\b|$)",raw,re.I)
    if m:
        z=re.split(r"\s+(?:need|want|looking|for|in|near|with)\b",clean(m.group(1)),flags=re.I)[0]
        if z: d["name"]=z.title()
    m=re.search(r"(?:\+91[\s-]?)?([6-9]\d{9})\b",x)
    if m: d["phone"]=m.group(1)
    return d

def merge(m,facts):
    changed={}
    for k,v in facts.items():
        if v and getattr(m,k,None)!=v:
            setattr(m,k,v); m.confidence[k]=.98; changed[k]=v
    m.updated_at=datetime.now().isoformat(timespec="seconds")
    return changed

def flow(m):
    p=n(m.property_type)
    if "plot" in p: return ["property_type","area","budget","plot_size","timeline"]
    if "commercial" in p: return ["property_type","area","budget","purpose","possession","timeline"]
    return ["property_type","area","budget","possession","timeline"]

def missing(m):
    return next((f for f in flow(m) if not getattr(m,f)),None)

def score(m):
    f=flow(m); s=round(sum(bool(getattr(m,x)) for x in f)/len(f)*75)
    if m.timeline and "1" in m.timeline: s+=20
    elif m.timeline: s+=10
    if m.phone: s+=5
    s=min(100,s); return s,("HOT" if s>=80 else "WARM" if s>=55 else "COLD")

QUEST={
"property_type":"What are you looking for — a 1/2/3 BHK, plot, commercial property, or something else?",
"area":"Which area or locality would you prefer? You can also say 'any area'.",
"budget":"What's your approximate budget? If budget isn't an issue, just say so and I'll keep it flexible.",
"possession":"Do you prefer ready-to-move or under-construction? You can also say no preference.",
"plot_size":"Roughly what plot size are you looking for? For example, 1,000 sq ft or 2 guntha.",
"purpose":"Is the commercial property mainly for your own use or investment?",
"timeline":"When are you planning to purchase — within a month, in a few months, or are you flexible?"
}

def respond(text,m=None):
    m=m or LeadMemory()
    if greeting(text) and not any(getattr(m,f) for f in flow(m)):
        s,st=score(m); return Result("Hi! 👋 Welcome. I can help you find a suitable property. What are you looking for?",m,{},missing(m),s,st,False)
    changed=merge(m,extract_facts(text)); miss=missing(m)
    if "already told" in n(text):
        reply="You're right 👍 I've kept what you've already told me. "
        reply += QUEST[miss] if miss else "I've got the full requirement. Would you like to arrange a call or property visit?"
    elif miss: reply=QUEST[miss]
    else:
        bits=[f"{FIELDS[f]}: {getattr(m,f)}" for f in flow(m)]
        reply="Perfect 👍 I've got the requirement: "+"; ".join(bits)+". Would you like to arrange a call or property visit?"
    s,st=score(m); return Result(reply,m,changed,miss,s,st,miss is None)
