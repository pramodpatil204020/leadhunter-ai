import unittest
from lead_engine import LeadMemory, extract_facts, respond

class TestLeadHunter(unittest.TestCase):
    def test_hi(self): self.assertIn("What are you looking for",respond("Hi").reply)
    def test_many_facts(self):
        f=extract_facts("Hi it's Pramod, need 3 bhk near CIDCO Nanded, budget 50 lac, want to move in 2 months")
        self.assertEqual(f["name"],"Pramod"); self.assertEqual(f["property_type"],"3 BHK")
        self.assertEqual(f["budget"],"₹50 lac"); self.assertIn("Cidco Nanded",f["area"]); self.assertEqual(f["timeline"],"Within 2 months")
    def test_budget_no_issue(self):
        r=respond("Budget no issue",LeadMemory(property_type="3 BHK",area="Cidco Nanded")); self.assertEqual(r.memory.budget,"Flexible / no fixed limit"); self.assertNotEqual(r.missing,"budget")
    def test_any_area(self):
        r=respond("Any area",LeadMemory(property_type="2 BHK",budget="₹45 lakh")); self.assertEqual(r.memory.area,"Any area / flexible"); self.assertNotEqual(r.missing,"area")
    def test_plot_no_possession(self):
        r=respond("I want empty plott near Nanded station",LeadMemory()); self.assertEqual(r.memory.property_type,"Plot"); self.assertEqual(r.missing,"budget"); self.assertNotIn("possession",r.reply.lower())
    def test_plot_size(self):
        r=respond("1000 sq ft",LeadMemory(property_type="Plot",area="Nanded Station",budget="Flexible / no fixed limit")); self.assertEqual(r.memory.plot_size,"1000 sq ft"); self.assertEqual(r.missing,"timeline")
    def test_already_told(self):
        m=LeadMemory(property_type="3 BHK",area="Cidco Nanded",budget="₹50 lakh",timeline="Within 2 months"); r=respond("I already told you",m); self.assertEqual(r.missing,"possession"); self.assertNotIn("budget",r.reply.lower())
    def test_flat_complete(self):
        m=LeadMemory()
        for x in ["I need 3 BHK","CIDCO Nanded, 50 lakh","ready to move","within 2 months"]: m=respond(x,m).memory
        r=respond("thanks",m); self.assertTrue(r.complete); self.assertIsNone(r.missing)
    def test_correction(self):
        r=respond("Actually 3 BHK and 50 lakh",LeadMemory(property_type="2 BHK",budget="₹40 lakh")); self.assertEqual(r.memory.property_type,"3 BHK"); self.assertEqual(r.memory.budget,"₹50 lakh")
    def test_commercial(self):
        r=respond("for investment",LeadMemory(property_type="Commercial",area="CIDCO",budget="₹1 crore")); self.assertEqual(r.memory.purpose,"Investment"); self.assertEqual(r.missing,"possession")
    def test_typos(self):
        f=extract_facts("I want empty plott near Nanded station"); self.assertEqual(f["property_type"],"Plot")
    def test_budget_variants(self):
        for x in ["any budget","money no issue","budget is flexible","no fixed budget"]: self.assertEqual(extract_facts(x)["budget"],"Flexible / no fixed limit")
    def test_two_or_three(self): self.assertEqual(extract_facts("I can't decide 2 or 3 BHK")["property_type"],"2 or 3 BHK")
    def test_phone(self): self.assertEqual(extract_facts("WhatsApp 9876543210")["phone"],"9876543210")
    def test_ready(self):
        r=respond("ready to move",LeadMemory(property_type="3 BHK",area="CIDCO",budget="₹50 lakh")); self.assertEqual(r.memory.possession,"Ready to move"); self.assertEqual(r.missing,"timeline")
    def test_score(self):
        r=respond("thanks",LeadMemory(property_type="3 BHK",area="CIDCO",budget="₹50 lakh",possession="Ready to move",timeline="Within 1 month")); self.assertGreaterEqual(r.score,80)

if __name__=="__main__": unittest.main()
