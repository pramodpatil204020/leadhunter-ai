# LeadHunter AI — VERIFIED FIX

The live-app bug was identified: the timeline parser did not recognize direct answers such as "in 2 months". The agent therefore kept asking the same timeline question.

This build fixes that and includes regression tests for the exact reported conversation.

Upload only app.py, lead_engine.py and requirements.txt to the existing GitHub repo. The LLM should not be used to decide which fields are missing; the deterministic engine does that.
