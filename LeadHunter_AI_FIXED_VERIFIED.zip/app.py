import streamlit as st
import pandas as pd
from datetime import datetime
from lead_engine import LeadMemory, FIELDS
from llm_agent import smart_respond, get_secret
from storage import init_db, save_lead, all_leads
from property_matcher import match_lead

st.set_page_config(page_title="LeadHunter AI", page_icon="🏠", layout="wide")
init_db()
st.title("🏠 LeadHunter AI")
st.caption("Developer-grade conversational real-estate lead agent")

if "memory" not in st.session_state: st.session_state.memory=LeadMemory()
if "messages" not in st.session_state: st.session_state.messages=[]

chat,dash,setup=st.tabs(["💬 Buyer Chat","📊 Broker Dashboard","⚙️ Setup"])

with chat:
    st.subheader("Talk naturally — no questionnaire");
    for x in st.session_state.messages:
        with st.chat_message(x["role"]): st.write(x["content"])
    m=st.session_state.memory
    known=[f"**{FIELDS[f]}:** {getattr(m,f)}" for f in FIELDS if getattr(m,f,None)]
    if known: st.info("🧠 Remembered — " + " | ".join(known))
    prompt=st.chat_input("Example: Hi, need 3 BHK near CIDCO Nanded, 50 lakh, move in 2 months")
    if prompt:
        history=st.session_state.messages[-8:]
        st.session_state.messages.append({"role":"user","content":prompt})
        r=smart_respond(prompt,st.session_state.memory,history)
        st.session_state.memory=r.memory
        st.session_state.messages.append({"role":"assistant","content":r.reply})
        st.session_state.last_result=r
        st.rerun()
    a,b=st.columns(2)
    with a:
        if st.button("💾 Save lead",use_container_width=True):
            m=st.session_state.memory
            if not m.property_type:
                st.warning("Start the conversation first.")
            else:
                r=getattr(st.session_state,"last_result",None)
                if r is None:
                    r=smart_respond("thanks",m,st.session_state.messages[-8:])
                data={
                    "saved_at":datetime.now().strftime("%Y-%m-%d %H:%M:%S"),"name":m.name or "","phone":m.phone or "",
                    "property_type":m.property_type or "","area":m.area or "","budget":m.budget or "",
                    "possession":m.possession or "","plot_size":m.plot_size or "","purpose":m.purpose or "",
                    "timeline":m.timeline or "","score":r.score,"status":r.status,
                    "conversation":"\n".join(f'{x["role"]}: {x["content"]}' for x in st.session_state.messages)
                }
                save_lead(data); st.success(f"Lead saved — {r.status} ({r.score}/100)")
    with b:
        if st.button("🗑️ New conversation",use_container_width=True):
            st.session_state.memory=LeadMemory(); st.session_state.messages=[]; st.rerun()
    if m.property_type and (m.area or m.budget):
        matches=match_lead(m)
        if matches:
            st.subheader("🏘️ Matching inventory")
            st.dataframe(pd.DataFrame(matches),use_container_width=True,hide_index=True)

with dash:
    st.subheader("Broker Dashboard")
    leads=all_leads()
    if not leads: st.info("No saved leads yet.")
    else:
        df=pd.DataFrame(leads)
        a,b,c,d=st.columns(4)
        a.metric("Total",len(df)); b.metric("🔥 Hot",int((df.status=="HOT").sum()))
        c.metric("🟠 Warm",int((df.status=="WARM").sum())); d.metric("⚪ Cold",int((df.status=="COLD").sum()))
        st.dataframe(df,use_container_width=True,hide_index=True)
        st.download_button("Download CSV",df.to_csv(index=False).encode(),"leadhunter_leads.csv","text/csv")

with setup:
    st.subheader("Production setup")
    if get_secret("OPENAI_API_KEY"):
        st.success(f"AI response polishing enabled — {get_secret('OPENAI_MODEL') or 'gpt-5.6-luna'}")
    else:
        st.info("Core memory engine is active. Add OPENAI_API_KEY in Streamlit Secrets for natural LLM response polishing.")
    st.write("The structured memory engine remains authoritative, so an LLM cannot accidentally make the agent re-ask known fields.")
    st.write("Next production integrations: WhatsApp Business API, CRM, broker notifications, real property feed and automated follow-up.")
    st.warning("Never put API keys in GitHub.")
