
import unittest
from lead_engine import extract, merge, next_missing, local_reply, required_fields

class TestFixedEngine(unittest.TestCase):
    def test_exact_reported_conversation(self):
        memory={}
        memory=merge(memory,extract("hi this is Pramod age 32 .. need a 3 bhk, budget no issue.. area in Nanded city ready to move"))
        self.assertEqual(memory["property_type"],"3 BHK")
        self.assertEqual(memory["budget"],"Flexible / no budget limit")
        self.assertIn("Nanded",memory["area"])
        self.assertEqual(memory["possession"],"Ready to move")
        self.assertEqual(next_missing(memory),"timeline")

        memory=merge(memory,extract("in 2 months"))
        self.assertEqual(memory["timeline"],"Within 2 months")
        self.assertIsNone(next_missing(memory))
        reply=local_reply("in 2 months",memory)
        self.assertNotIn("When are you planning",reply)

    def test_greeting(self):
        self.assertIn("What are you looking for",local_reply("Hi",{}))

    def test_budget_no_issue(self):
        m=merge({},extract("budget no issue"))
        self.assertEqual(m["budget"],"Flexible / no budget limit")
        self.assertNotEqual(next_missing(m),"budget")

    def test_any_area(self):
        m=merge({},extract("any area"))
        self.assertEqual(m["area"],"Flexible / any area")
        self.assertNotEqual(next_missing(m),"area")

    def test_plot_flow(self):
        m=merge({},extract("empty plott near Nanded station"))
        self.assertEqual(m["property_type"],"Plot")
        self.assertEqual(next_missing(m),"budget")
        m=merge(m,extract("budget no issue"))
        self.assertEqual(next_missing(m),"plot_size")
        self.assertNotIn("possession",required_fields(m))

    def test_two_or_three(self):
        self.assertEqual(extract("2 or 3 BHK")["property_type"],"2 or 3 BHK")

    def test_correction(self):
        m={"property_type":"2 BHK","budget":"₹40 lakh"}
        m=merge(m,extract("Actually 3 BHK and 50 lakh"))
        self.assertEqual(m["property_type"],"3 BHK")
        self.assertEqual(m["budget"],"₹50 lakh")

    def test_direct_timeline_variants(self):
        for phrase,want in [("in 2 months","Within 2 months"),("within 3 months","Within 3 months"),("after 4 months","Within 4 months"),("2-3 months","2–3 months")]:
            self.assertEqual(extract(phrase)["timeline"],want)

if __name__=="__main__":
    unittest.main()
